<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Divisions;


class divisionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $divisions = new Divisions;
        $divisions->Division_name = "AFC North";
        $divisions->SuperBowl_Titles = 5;
        $divisions->save();

        $divisions = new Divisions;
        $divisions->division_name = "AFC North";
        $divisions->SuperBowl_Titles = 3;
        $divisions->save();

        $divisions = new Divisions;
        $divisions->division_name = "AFC North";
        $divisions->SuperBowl_Titles = 6;
        $divisions->save();

        $divisions = new Divisions;
        $divisions->division_name = "AFC North";
        $divisions->SuperBowl_Titles = 2;
        $divisions->save();

        $divisions = new Divisions;
        $divisions->Division_name = "AFC North";
        $divisions->SuperBowl_Titles = 1;
        $divisions->save();

        $divisions = new Divisions;
        $divisions->Division_name = "AFC North";
        $divisions->SuperBowl_Titles = 5;
        $divisions->save();

        $divisions = new Divisions;
        $divisions->Division_name = "AFC North";
        $divisions->SuperBowl_Titles = 0;

        $divisions = new Divisions;
        $divisions->Division_name = "AFC North";
        $divisions->SuperBowl_Titles = 9;
        $divisions->save();

    }
}
