<?php

namespace Database\Seeders;
use App\Models\Conferences;


use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ConferencesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $Conferences = new Conferences;
        $Conferences->Conference_name= 'american football';
        $Conferences->Conference_logo= 'asdcsde';
        $Conferences->Superbowl_titles= 30;
        $Conferences->save();

        $Conferences = new Conferences;
        $Conferences->Conference_name= 'national football';
        $Conferences->Conference_logo= 'asdcsde';
        $Conferences->Superbowl_titles= 30;
        $Conferences->save();
    }
}
