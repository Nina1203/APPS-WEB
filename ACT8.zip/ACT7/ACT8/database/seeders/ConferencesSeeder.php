<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Conferencias;

class ConferencesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $conferencia = new Conferencias;
        $conferencia->nombre_conferencia = "American Football Conference";
        $conferencia->logo = "qwefrrf";
        $conferencia->sb_conferencia = 30;
        $conferencia->save();

        $conferencia = new Conferencias;
        $conferencia->nombre_conferencia = "National Football Conference";
        $conferencia->logo = "desrgr";
        $conferencia->sb_conferencia = 30;
        $conferencia->save();
    }
}
