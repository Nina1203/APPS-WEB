<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Divisiones;

class DivisionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $division = new Divisiones;
        $division->nombre_division = "AFC North";
        $division->logo = "qwedwdew";
        $division->sb_division = 25;
        $division->save();

        $division = new Divisiones;
        $division->nombre_division = "AFC South";
        $division->logo = "qwedwdew";
        $division->sb_division = 25;
        $division->save();

        $division = new Divisiones;
        $division->nombre_division = "AFC East";
        $division->logo = "qwdede";
        $division->sb_division = 20;
        $division->save();

        $division = new Divisiones;
        $division->nombre_division = "AFC West";
        $division->logo = "qedsdfd";
        $division->sb_division = 20;
        $division->save();

        #NFC

        $division = new Divisiones;
        $division->nombre_division = "NFC North";
        $division->logo = "qwedwdew";
        $division->sb_division = 25;
        $division->save();

        $division = new Divisiones;
        $division->nombre_division = "NFC South";
        $division->logo = "qwedwdew";
        $division->sb_division = 25;
        $division->save();

        $division = new Divisiones;
        $division->nombre_division = "NFC East";
        $division->logo = "urlasdfd";
        $division->sb_division = 20;
        $division->save();

        $division = new Divisiones;
        $division->nombre_division = "NFC West";
        $division->logo = "qwedwdew";
        $division->sb_division = 20;
        $division->save();
       
    }
}
